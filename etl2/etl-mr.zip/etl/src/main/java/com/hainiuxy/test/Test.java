/**
 * Test.java
 * com.hainiuxy.test
 * Copyright (c) 2019, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.test;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 可配置定时分钟、定时小时、指定小时
 * @author   潘牛                      
 * @Date	 2019年3月9日 	 
 */
public class Test {


	public static void main(String[] args) throws Exception {
		// 1: 定点分钟间隔 rollInterval 单位：分钟
		// 2: 定点小时间隔 rollInterval 单位：小时
		// 3: 指定小时
		long userDefineRollIntervalFlag = 3;
		long rollInterval = 0; 
		String hours_str = "1,3,6,22,23";
		//定点分钟间隔
		if (userDefineRollIntervalFlag == 1) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
			Calendar c = Calendar.getInstance();
			Date now = new Date();
			c.setTime(now);
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			
			String month_str = ((int)month/10) == 0 ? "0" + month : String.valueOf(month);
			String day_str = ((int)day/10) == 0 ? "0" + day : String.valueOf(day);
			int hour = c.get(Calendar.HOUR_OF_DAY);
			
			StringBuilder day_hour = new StringBuilder();
			day_hour.append(year).append(month_str).append(day_str);
			
			String minute_str = ((int) rollInterval / 10) == 0 ? "0" + rollInterval : String.valueOf(rollInterval);
			
			day_hour.append(hour).append(minute_str);
			System.out.println("day_hour:" + day_hour.toString());
			Date date = sdf.parse(day_hour.toString());
			Calendar c_end = Calendar.getInstance();
			c_end.setTime(date);
			System.out.println(sdf1.format(date));
			
			if(c.getTimeInMillis() > c_end.getTimeInMillis()){
				c_end.add(Calendar.HOUR_OF_DAY, 1);
			}

			double nextMinutes = (double)(c_end.getTimeInMillis() - c.getTimeInMillis()) / 60 / 1000;
			
			String format = "######.##";
			DecimalFormat formatter = new DecimalFormat(format);

			System.out.println(c_end.getTimeInMillis() - c.getTimeInMillis());
			System.out.println(formatter.format(nextMinutes) + "分钟");

		} else if (userDefineRollIntervalFlag == 2) {
			//定点小时间隔
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");
			Calendar c = Calendar.getInstance();
			Date now = new Date();
			c.setTime(now);
			int year = c.get(Calendar.YEAR);
			int month = c.get(Calendar.MONTH) + 1;
			int day = c.get(Calendar.DAY_OF_MONTH);
			
			String month_str = ((int)month/10) == 0 ? "0" + month : String.valueOf(month);
			String day_str = ((int)day/10) == 0 ? "0" + day : String.valueOf(day);
			String hour_str = ((int) rollInterval / 10) == 0 ? "0" + rollInterval : String.valueOf(rollInterval);
			
			
			
			StringBuilder day_hour = new StringBuilder();
			day_hour.append(year).append(month_str).append(day_str).append(hour_str);
			
			System.out.println("day_hour:" + day_hour.toString());
			Date date = sdf.parse(day_hour.toString());
			Calendar c_end = Calendar.getInstance();
			c_end.setTime(date);
			System.out.println(sdf1.format(date));
			
			if(c.getTimeInMillis() > c_end.getTimeInMillis()){
				c_end.add(Calendar.DAY_OF_MONTH, 1);
			}

			double nextHour = (double)(c_end.getTimeInMillis() - c.getTimeInMillis()) / 3600 / 1000;
			
			String format = "######.##";
			DecimalFormat formatter = new DecimalFormat(format);

			System.out.println(c_end.getTimeInMillis() - c.getTimeInMillis());
			System.out.println(formatter.format(nextHour) + "小时");
			
		
		} else if (userDefineRollIntervalFlag == 3){
			//指定小时
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHH");
			try {
				Calendar c = Calendar.getInstance();
				Date now = new Date();
				c.setTime(now);
				
				int year = c.get(Calendar.YEAR);
				int month = c.get(Calendar.MONTH) + 1;
				int day = c.get(Calendar.DAY_OF_MONTH);
				String month_str = ((int)month/10) == 0 ? "0" + month : String.valueOf(month);
				String day_str = ((int)day/10) == 0 ? "0" + day : String.valueOf(day);
				String[] splits = hours_str.split(",");
				if(splits == null){
					throw new Exception("数据错误");
				}
				int i = 0;
				for(; i < splits.length; i++){
					String day_hour = "" + year  + month_str + day_str + splits[i] ;
					System.out.println(day_hour);
					Date date = sdf.parse(day_hour);
					if(date.getTime() - now.getTime() > 0){
						System.out.println((float)(date.getTime() - now.getTime())/1000/3600 + "小时");
						break;
					}
				}
				if(i == splits.length){
					c.add(Calendar.DATE, 1);// 日期加1
					year = c.get(Calendar.YEAR);
					month = c.get(Calendar.MONTH) + 1;
					day = c.get(Calendar.DAY_OF_MONTH);
					month_str = ((int)month/10) == 0 ? "0" + month : String.valueOf(month);
					day_str = ((int)day/10) == 0 ? "0" + day : String.valueOf(day);
					String day_hour = "" + year  + month_str + day_str + splits[0] ;
					System.out.println(day_hour);
					Date date = sdf.parse(day_hour);
					System.out.println((float)(date.getTime() - now.getTime())/1000/3600 + "小时");
					
				}

			} catch (ParseException e) {
				
				e.printStackTrace();
				
			}
		}
	}
}
