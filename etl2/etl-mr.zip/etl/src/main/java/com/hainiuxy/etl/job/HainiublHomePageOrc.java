/**
 * HainiublHomePageOrc.java
 * com.hainiuxy.etl
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapreduce.AvroJob;
import org.apache.avro.mapreduce.AvroKeyInputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.ql.io.orc.OrcNewOutputFormat;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.orc.CompressionKind;

import com.hainiuxy.etl.base.BaseMR;
import com.hainiuxy.etl.util.DictUtil;
import com.hainiuxy.etl.util.IPUtil;
import com.hainiuxy.etl.util.OrcUtil;

/**
 * 筛选hainiubl首页的页面的12个链接请求的数据转化成orc文件
 * @author   潘牛                      
 * @Date	 2018年11月1日 	 
 */
public class HainiublHomePageOrc extends BaseMR{
	
	public static Schema schema = null;
	
	public static Schema.Parser parse = new Schema.Parser();
	
	public static class HainiublHomePageOrcMapper extends Mapper<AvroKey<GenericRecord>, NullWritable, NullWritable, Writable>{
		
		private DictUtil dictUtil = new DictUtil();
		
		private IPUtil ipUtil = new IPUtil();
		
		
		
		Text keyOut = new Text();
		
		OrcUtil orcUtil = new OrcUtil();
		
		@Override
		protected void setup(Context context)
				throws IOException, InterruptedException {
			ipUtil.loadIPFile();
			String orc_schema = "struct<area:string,timeLocal:string,req_url:string,"
					+ "url_describe:string,who_req:string,spider_type:string,user_agent:string>";
			orcUtil.setWriteInspector(orc_schema);
			dictUtil.loadFile();
			
		}
		
		@Override
		protected void map(AvroKey<GenericRecord> key, NullWritable value,Context context)
				throws IOException, InterruptedException {
			GenericRecord record = key.datum();
			String remote_ip = String.valueOf(record.get("remote_ip"));
			String time_local = String.valueOf(record.get("time_local"));
			String req_type = String.valueOf(record.get("req_type"));
			String req_url = String.valueOf(record.get("req_url"));
			String who_req = String.valueOf(record.get("who_req"));
			String user_agent = String.valueOf(record.get("user_agent"));
			
			String url_describe = "";
//			System.out.println(req_url);
			
			if(! checkHomePageReqData(req_type, req_url, who_req)){
//				System.out.println("===>不匹配url: " + req_url + "\t\t" + who_req);
				return;
			}
			
			url_describe = dictUtil.getReqUrl(req_url);
			
			
			
			//确定是什么爬虫
			String spider_type = dictUtil.getSpiderType(user_agent);
			
			//获取ip对应的区域
			String area = ipUtil.getIpArea(remote_ip);
			if(Pattern.matches(".*省.*", area)){
				area = area.substring(0, area.indexOf("省") + 1);
			}else if(Pattern.matches("内蒙古.*", area)){
				area = area.substring(0, 3);
			}else if(Pattern.matches("(^西藏|^广西|^宁夏|^新疆).*", area)){
				area = area.substring(0, 2);
			}else if(Pattern.matches(".*市.*", area)){
				area = area.substring(0, area.indexOf("市") + 1);
			}
			
//			System.out.println(area + "\001" + req_type + "\001" + req_url + "\001" + url_describe + "\001" + who_req + "\001" + spider_type + "\001" + user_agent);
			//要写入orc文件的数据 
			List<Object> realRow = new ArrayList<Object>();
			realRow.add(area);
			realRow.add(time_local);
			realRow.add(req_url);
			realRow.add(url_describe);
			realRow.add(who_req);
			realRow.add(spider_type);
			realRow.add(user_agent);

			
			//将这些数据序列化到orc写Writable
			Writable w = orcUtil.serialize(realRow);
			
			context.write(NullWritable.get(), w);
		}



		/**
		 * 筛选符合条件的请求url，筛选条件如下：
		 * 1）请求类型是get
		 * 2）请求url是首页的12个页面链接url
		 * 3）哪个url请求的，必须是海牛首页请求的url
		 * @param req_type 请求类型
		 * @param req_url  请求url
		 * @param who_req  哪个url请求的
		 * @return TODO(这里描述每个参数,如果有返回值描述返回值,如果有异常描述异常)
		*/
		private boolean checkHomePageReqData(String req_type, String req_url, String who_req) {
			if(! "GET".equals(req_type)){
				return false;
			}
			
			// 匹配true；不匹配false
			boolean requrlMatchFlag = Pattern.matches("(^/categories/9\\?filter=recent |^/topics/44 "
					+ "|^/topics/181 |^/topics/182 |^/topics/176 |^/topics/177 |^/topics/186 "
					+ "|^/topics/187 |^/topics/198 |^/topics/199 |^/topics/202 |^/topics/223 "
					+ ").*", req_url);
			
			// 验证refer
//			boolean whoreqMatchFlag = "http://www.hainiubl.com/".equals(who_req);
//			if(requrlMatchFlag && whoreqMatchFlag){
////				System.out.println(req_url + "\001" + who_req);
//				return true;
//			}
			
			// 不验证refer
			if(requrlMatchFlag){
//				System.out.println(req_url + "\001" + who_req);
				return true;
			}
		
			return false;
			
		}
		
	}

	@Override
	public Job getJob(Configuration conf) throws Exception {
	
		//设置orc文件snappy压缩
		conf.set("orc.compress", CompressionKind.SNAPPY.name());
		//设置orc文件 有索引
		conf.set("orc.create.index", "true");
		
		Job job = Job.getInstance(conf, getJobNameWithTaskId());
		
		job.setJarByClass(HainiublHomePageOrc.class);
		
		job.setMapperClass(HainiublHomePageOrcMapper.class);
		
		//无reduce
		job.setNumReduceTasks(0);
		
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(Writable.class);
		
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Writable.class);
		
		job.setInputFormatClass(AvroKeyInputFormat.class);
		
		job.setOutputFormatClass(OrcNewOutputFormat.class);
		
		//根据配置的avro.txt 配置文件，获取对应的schema对象
		schema = parse.parse(HainiublHomePageOrc.class.getResourceAsStream("/hainiubl_avro.txt"));
		
		AvroJob.setInputKeySchema(job, schema);
		
		FileInputFormat.addInputPath(job, getFirstJobInputPath());
		
		FileOutputFormat.setOutputPath(job, getJobOutputPath(getJobNameWithTaskId()));
		
		return job;
	}

	@Override
	public String getJobName() {
		
		return "homepage_orc";
		
	}

}

