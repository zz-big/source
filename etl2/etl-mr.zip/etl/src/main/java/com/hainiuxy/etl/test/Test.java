/**
 * Test.java
 * com.hainiuxy.etl
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.test;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * TODO(这里用一句话描述这个类的作用)
 * <p>
 * TODO(这里描述这个类补充说明 – 可选)
 * @author   潘牛                      
 * @Date	 2018年10月31日 	 
 */
public class Test {
	/*GET /index.action HTTP/1.1
	GET /search
	GET /topics
	GET /user
	GET /users
	POST /index.php?m=member&c=index&a=register&siteid=1 HTTP/1.1
	POST /login.action HTTP/1.1
	POST /replies
	POST /signin HTTP/1.1
	POST /signup HTTP/1.1
	POST /topics
	POST /topics HTTP/1.1
	POST /user
	POST /users*/
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
//		list.add("GET /index.action HTTP/1.1");
//		list.add("GET /search");
//		list.add("GET /topics");
//		list.add("GET /user");
//		list.add("GET /users");
//		list.add("POST /index.php?m=member&c=index&a=register&siteid=1 HTTP/1.1");
//		list.add("POST /login.action HTTP/1.1");
//		list.add("POST /replies");
//		list.add("POST /signin HTTP/1.1");
//		list.add("POST /signup HTTP/1.1");
//		list.add("POST /topi");
//		list.add("POST /topics HTTP/1.1");
//		list.add("POST /user");
//		list.add("POST /users");
//		for(String str : list){
//			boolean b = Pattern.matches("(^GET /index.action|^GET /search|^GET /topics|GET"
//					+ " /user|^GET /users|^POST /index.php|^POST /login.action|^POST /replies|^POST "
//					+ "/signin|^POST /signup|^POST /topics|^POST /user|^POST /users).*", str);
//			System.out.println(str + "\t\t" + b);
//		}
		
//		list.add("/categories/9?filter=recent dsfsdafs");
//		list.add("/topics/44 safsdfsdafsad");
//		list.add("/topics/181   sdafasdfas");
//		list.add("/topics/182 sdfsadfsaf");
//		list.add("/topics/176  HTTP/1.1");
//		list.add("/topics/177");
//		list.add("/topics/186");
//		list.add("/topics/187");
//		list.add("/topics/198");
//		list.add("/topics/199");
//		list.add("/topics/202");
//		list.add("/topics/223");
//		for(String str : list){
//		boolean b = Pattern.matches("(^/categories/9\\?filter=recent |^/topics/44 |^/topics/181 |^/topics/182 |^/topics/176 |^/topics/177 |^/topics/186 |^/topics/187 |^/topics/198 |^/topics/199 |^/topics/202 |^/topics/223 ).*", str);
//		System.out.println(str + "\t\t" + b);
//	   }
//		
		
		
		
		list.add("/topics/44 HTTP/1.1");
		list.add("/topics/35977 HTTP/1.1");
		list.add("/topics/417?page=36 HTTP/1.1");
		list.add("/topics/2222222 HTTP/1.1");
		list.add("/topics/ HTTP/1.1");
		list.add("/topics HTTP/1.1");
		for(String str : list){
			boolean b = Pattern.matches("^/topics(\\s+|/\\s+|/\\d{1,6}(\\?|\\s+|/)).*", str);
			System.out.println(str + "\t\t" + b);
		}
		
		
//		String who_req = "www.hainiubl/categories/199";
//		who_req = who_req.contains("?") ? who_req.substring(who_req.indexOf("/categories"), 
//				who_req.indexOf("?")) : who_req.substring(who_req.indexOf("/categories")) ;
//		System.out.println(who_req);
//		IPUtil ipUtil = new IPUtil();
//		ipUtil.loadIPFile();
//		String area = ipUtil.getIpArea("128.10.255.200");
		
		
//		String area = "西藏乌鲁木齐市";
//		if(Pattern.matches(".*省.*", area)){
//			area = area.substring(0, area.indexOf("省") + 1);
//		}else if(Pattern.matches("内蒙古.*", area)){
//			area = area.substring(0, 3);
//		}else if(Pattern.matches("(^西藏|^广西|^宁夏|^新疆).*", area)){
//			area = area.substring(0, 2);
//		}else if(Pattern.matches(".*市.*", area)){
//			area = area.substring(0, area.indexOf("市") + 1);
//		}
//		System.out.println(area);
	}

}

