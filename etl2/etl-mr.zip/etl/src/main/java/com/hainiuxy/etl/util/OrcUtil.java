/**
 * OrcUtil.java
 * com.hainiuxy.mrrun.util
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.hive.ql.io.orc.OrcSerde;
import org.apache.hadoop.hive.ql.io.orc.OrcStruct;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructField;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfo;
import org.apache.hadoop.hive.serde2.typeinfo.TypeInfoUtils;
import org.apache.hadoop.io.Writable;

/**
 * Orc工具类<br/>
 * 用于读写orc文件<br/>
 * 读取：  根据schema获取inspector_r  -----》    getOrcData() 获取数据<br/>
 * setReadInspector();<br/>
 * getOrcData();<br/>
 * 写：   根据schema获取inspector_w   ---》 将数据序列化到Writable<br/>
 * setWriteInspector();<br/>
 * serialize();
 * @author   潘牛                      
 * @Date	 2018年10月22日 	 
 */
public class OrcUtil {
	
	/**
	 * 读orc文件的inspector
	 */
	private StructObjectInspector inspector_r = null;
	
	/**
	 * orc写的inspector
	 */
	ObjectInspector inspector_w = null;
	
	
	/**
	 * 要写入orc文件的数据 
	 */
	List<Object> realRow = new ArrayList<Object>();
	
	/**
	 * 根据schema 获取inspector_r
	 * @param schema orc结构字符串
	*/
	public void setReadInspector(String schema){
		//通过schema，获取到指定的typeinfo类型【复合结构struct】
		TypeInfo typeInfo = TypeInfoUtils.getTypeInfoFromTypeString(schema);
		//获取struct结构的 对象StructObjectInspector
		inspector_r = (StructObjectInspector) OrcStruct.createObjectInspector(typeInfo);
	}
	
	/**
	 * 获取orcStruct的对象里面的具体key数据，如果数据为null "" "null",都转换为 "null"
	 * @param orcObj orcStruct的对象（数据在这里）
	 * @param key 具体字段
	 * @return key数据
	*/
	public String getOrcData(OrcStruct orcObj, String key) {
		// inspector 先获取到指定字段的StructField
		StructField field = inspector_r.getStructFieldRef(key);
		// inspector 去 OrcStruct里面，拿指定的字段的 StructField 的值
		String data = String.valueOf(inspector_r.getStructFieldData(orcObj, field));
		if(data == null || data.equals("") || data.equalsIgnoreCase("null")){
			data = "null";
		}
		return data;
	}
	
	/**
	 * 根据schema 获取inspector_w
	 * @param schema orc结构字符串
	*/
	public void setWriteInspector(String schema){
		//通过schema，获取到指定的typeinfo类型【复合结构struct】
		TypeInfo typeInfo = TypeInfoUtils.getTypeInfoFromTypeString(schema);
		// 获取写的inspector对象
		inspector_w = TypeInfoUtils.getStandardJavaObjectInspectorFromTypeInfo(typeInfo);
	}
	
	
	/**
	 * 将这些数据序列化到orc写Writable
	 * @param realRow 要序列化的数据
	 * @return Writable 
	*/
	public Writable serialize(List<Object> realRow){
		//如果serde
		OrcSerde serde = new OrcSerde();
		return serde.serialize(realRow, inspector_w);
	}
	
	

}

