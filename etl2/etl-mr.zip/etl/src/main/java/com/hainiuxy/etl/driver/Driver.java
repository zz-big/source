/**
 * Driver.java
 * com.hainiuxy.mrrun.driver
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.driver;

import org.apache.hadoop.util.ProgramDriver;

import com.hainiuxy.etl.job.HainiublCategoryOrcJob;
import com.hainiuxy.etl.job.HainiublEtlToAvroJob;
import com.hainiuxy.etl.job.HainiublHomePageOrcJob;

/**
 * 驱动类
 * 
 * @author 潘牛
 * @Date 2018年9月29日
 */
public class Driver {

	public static void main(String[] args) {
		int exitCode = -1;
		ProgramDriver pgd = new ProgramDriver();
		try {
			
			pgd.addClass("txt2avro", HainiublEtlToAvroJob.class, "txt文件转avro文件");
			
			pgd.addClass("avro2homepage_orc", HainiublHomePageOrcJob.class, "首页链接转化url的orc文件");
			
			pgd.addClass("avro2category_orc", HainiublCategoryOrcJob.class, "category、topics 关系orc文件");
			
			//运行的时候，找到是对应任务的类class的main(),调用其main()执行
			exitCode = pgd.run(args);
		} catch (Throwable e) {
			e.printStackTrace();
		}

		System.exit(exitCode);
	}

}
