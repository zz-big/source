/**
 * HainiublEtlToAvro.java
 * com.hainiuxy.etl
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapreduce.AvroJob;
import org.apache.avro.mapreduce.AvroKeyOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.hainiuxy.etl.base.BaseMR;

/**
 * @author   潘牛                      
 * @Date	 2018年10月31日 	 
 */
public class HainiublEtlToAvro extends BaseMR{
	
	public static Schema schema = null;
	
	public static Schema.Parser parse = new Schema.Parser();
	
	public static class HainiublEtlToAvroMapper extends Mapper<LongWritable, Text, AvroKey<GenericRecord>, NullWritable>{
		
		@Override
		protected void setup(Mapper<LongWritable, Text, AvroKey<GenericRecord>, NullWritable>.Context context)
				throws IOException, InterruptedException {
			//集群运行时，需要把这段代码加上
			if (schema == null){
				Schema.Parser parse = new Schema.Parser();
				schema = parse.parse(HainiublEtlToAvro.class.getResourceAsStream("/hainiubl_avro.txt"));				
			}
		}
		
		@Override
		protected void map(LongWritable key, Text value,Context context)
				throws IOException, InterruptedException {
			
			context.getCounter("hainiubl_log", "total num").increment(1L);
			String[] split = value.toString().split("\001");
			if(! checkValid(split)){
				context.getCounter("hainiubl_log", "invalid num").increment(1L);
				return;
			}
			
			//统计有效的数据个数
			context.getCounter("hainiubl_log", "valid num").increment(1L);
//			---post
//			0)180.76.237.209
//			1)-
//			2)14/Dec/2017:02:43:36 +0800
//			3)POST /index.php HTTP/1.1
//			4)500
//			5)4571
//			6)siteid=1&modelid=11&username=kfc211784
//			7)-
//			8)Mozilla/4.0 (compatible; Win32; WinHttp.WinHttpRequest.5)
//			9)-
			String remoteIp = split[0]; 
			String timeStr = split[2];
			String requestStr = split[3];
			String status = split[4];
			String post_req_params = split[6];
			String who_req = split[7];
			String user_agent = split[8];
			//yyyyMMddHHmmss
			String timeLocal = null;
			//02/Mar/2018:16:38:16
			timeStr = timeStr.substring(1, timeStr.indexOf(" "));
			//格式化 02/Mar/2018:16:38:16
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss", Locale.ENGLISH);
			//格式化 yyyyMMddHHmmss
			SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
			try {
				Date date1 = sdf1.parse(timeStr);
				timeLocal = sdf2.format(date1);
				
			} catch (ParseException e) {

				e.printStackTrace();
				
			}
			//统计有效访问ip
			if(remoteIp != null && !remoteIp.equals("")){
				context.getCounter("hainiubl_log", "ip num").increment(1L);
			}
			
			
			String req_type = requestStr.substring(0, 3);
			String req_url = requestStr.substring(4);
			if(! req_type.equals("GET")){
				req_type =  requestStr.substring(0, 4);
				req_url = requestStr.substring(5);
			}
			
//			System.out.println("-------------------");
//			System.out.println("remote_ip:" + remoteIp);
//			System.out.println("time_local:" + timeLocal);
//			System.out.println("req_type:" + req_type);
//			System.out.println("req_url:" + req_url);
//			System.out.println("status:" + status);
//			System.out.println("who_req:" + who_req);
//			System.out.println("post_req_params:" + post_req_params);
//			System.out.println("user_agent:" + user_agent);
			
			//--------------写到avro逻辑---------------------------------------
			//相当于avro的一条记录
			GenericRecord record = new GenericData.Record(HainiublEtlToAvro.schema);
			record.put("remote_ip", remoteIp);
			record.put("time_local", timeLocal);
			record.put("req_type", req_type);
			record.put("req_url", req_url);
			record.put("status", status);
			record.put("who_req", who_req);
			record.put("post_req_params", post_req_params);
			record.put("user_agent", user_agent);
		
			//将avro格式 写出
			context.write(new AvroKey<GenericRecord>(record), NullWritable.get());
		}

		/**
		 * 校验日志是否是有效数据，如果不是，返回false
		 * @param splits
		 * @return 
		*/
		private boolean checkValid(String[] splits) {
			if (splits.length != 10){
				return false;
			}
			
			String req = splits[3];
			boolean flag = Pattern.matches("(^GET /index.action|^GET /search|^GET /topics|GET"
					+ " /user|^GET /users|^POST /index.php|^POST /login.action|^POST /replies|^POST "
					+ "/signin|^POST /signup|^POST /topics|^POST /user|^POST /users|^GET /categories).*", req);
			
			if(!flag){
				return false;
			}
			/*GET /index.action HTTP/1.1
			GET /search
			GET /topics
			GET /user
			GET /users
			POST /index.php?m=member&c=index&a=register&siteid=1 HTTP/1.1
			POST /login.action HTTP/1.1
			POST /replies
			POST /signin HTTP/1.1
			POST /signup HTTP/1.1
			POST /topics
			POST /topics HTTP/1.1
			POST /user
			POST /users*/
			return true;
			
		}
	}
	
	@Override
	public Job getJob(Configuration conf) throws Exception {
		
		Job job = Job.getInstance(conf, getJobNameWithTaskId());
		
		job.setJarByClass(HainiublEtlToAvro.class);
		
		job.setMapperClass(HainiublEtlToAvroMapper.class);
		
		//无reduce
		job.setNumReduceTasks(0);
		
		
		job.setMapOutputKeyClass(AvroKey.class);
		job.setMapOutputValueClass(NullWritable.class);
		
		job.setOutputKeyClass(AvroKey.class);
		job.setOutputValueClass(NullWritable.class);
		
		//【重要】avro输出format
		job.setOutputFormatClass(AvroKeyOutputFormat.class);
		
		//根据配置的avro.txt 配置文件，获取对应的schema对象
		schema = parse.parse(HainiublEtlToAvro.class.getResourceAsStream("/hainiubl_avro.txt"));
		//设置输出schema
		AvroJob.setOutputKeySchema(job, schema);
		
		FileInputFormat.addInputPath(job, getFirstJobInputPath());
		
		FileOutputFormat.setOutputPath(job, getJobOutputPath(getJobNameWithTaskId()));
		
		
		return job;
		
	}

	@Override
	public String getJobName() {
		
		return "txt2avro";
		
	}

}

