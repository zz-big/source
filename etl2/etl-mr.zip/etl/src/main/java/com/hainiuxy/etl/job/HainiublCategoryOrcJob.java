/**
 * WordMaxJob.java
 * com.hainiuxy.mrrun
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.hainiuxy.etl.util.JobRunResult;
import com.hainiuxy.etl.util.JobRunUtil;

/**
 *  txt 文件转avro文件的任务链
 * @author   潘牛                      
 * @Date	 2018年9月29日 	 
 */
public class HainiublCategoryOrcJob extends Configured implements Tool{

	@Override
	public int run(String[] args) throws Exception {
		//通过getConf(),获取configuration，这样可以把-D参数传过来
		Configuration conf = getConf();
		
		//创建任务链JobControl对象
		JobControl jobc = new JobControl("HainiublCategoryOrc");
		
		HainiublCategoryOrc orc = new HainiublCategoryOrc();
		orc.setConf(conf);
		
		ControlledJob toOrcJob = orc.getControlledJob();
	
		jobc.addJob(toOrcJob);
		
		
		
		JobRunResult result = JobRunUtil.run(jobc);
		result.print(true);
		
		return 0; 
		
	}


	
	public static void main(String[] args) throws Exception {
//		-Dtask.id=1220_cateory -Dtask.input.dir=/tmp/etl/orc/input -Dtask.base.dir=/tmp/etl/orc
		System.exit(ToolRunner.run(new HainiublCategoryOrcJob(), args));
	}

}

