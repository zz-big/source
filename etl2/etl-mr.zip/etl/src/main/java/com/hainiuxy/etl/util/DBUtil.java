/**
 * DBUtil.java
 * com.hainiuxy.mrrun.util
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * @author   潘牛                      
 * @Date	 2018年11月1日 	 
 */
public class DBUtil {
	
	private static final String JDBC_FILE_NAME="jdbc.properties";
	
	private DBUtil(){
		
	}
	
	private static Connection conn = null;
	
	public static Connection getConnection(){
		if(conn != null){
			return conn;
		}
		
		Properties prop = new Properties();
		try {
			prop.load(DBUtil.class.getResourceAsStream("/jdbc.properties"));
			String driver = (String)prop.get("jdbc.driver");
			String url = (String)prop.get("jdbc.url");
			String user = (String)prop.get("jdbc.user");
			String password = (String)prop.get("jdbc.password");
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
			return conn;
		} catch (Exception e) {
			
			e.printStackTrace();
			
		}
		
		return conn;
	}
	
	public static void release(Connection conn){
		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
		}
	}

	
}

