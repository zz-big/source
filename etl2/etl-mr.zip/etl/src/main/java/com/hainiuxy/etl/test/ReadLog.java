/**
 * ReadLog.java
 * com.hainiuxy.etl.test
 * Copyright (c) 2019, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;



/**
 * 读取多个日志最新的信息，汇总到一个日志文件中
 * @author   潘牛                      
 * @Date	 2019年4月27日 	 
 */
public class ReadLog {

	public static String[] logArr = { "etl", "addpartition", "txt2avro", "avro_mv_hive", "avro2homepage_orc",
			"orc_mv_hive", "orc_export_data", "data_import_mysql",

			"avro2categories_orc", "orc_categories_mv_hive", "orc_categories_export_data",
			"data_categories_import_mysql"

	};
	public static Map<String, Long> map = new HashMap<String, Long>();

	public static void main(String[] args) {
		if (args == null || args.length == 0) {
			throw new RuntimeException("输入参数不全");
		}
		
		System.out.println(Arrays.toString(logArr));
		System.out.println("length:" + logArr.length);

		String log_base_path = args[0];
		// 记录读取日志位置的文件
		String position_path = log_base_path + "/position/etl.position";
		// 最后生成的日志文件
		String target_path = log_base_path + "/my.log";
		// 把位置加载到map
		readPosition(position_path);

		try (BufferedWriter out = new BufferedWriter(new FileWriter(target_path));) {
			// 循环遍历每个文件的数据，写入 my.log 文件
			for (int i = 0; i < logArr.length; i++) {
				String name = logArr[i];
				String logFile = log_base_path + "/" + name + ".log";
				
				readLogWriteTargetFile(name, logFile, out);
				
			}
			// 将最新的位置信息持久到文件
			writePosition(position_path);

		} catch (IOException e) {

			e.printStackTrace();
		}


	}

	/**
	 * 读取一个文件的内容写入目标文件流中<br/>
	 * 步骤：<br/>
	 * 1）获取读取文件的位置；<br/>
	 * 2）增量读取文件内容写入到目标文件<br/>
	 * 3）更新最后读取读取内容位置<br/>
	 * @param name  文件名
	 * @param logFile 带路径的文件名
	 * @param out 
	*/
	private static void readLogWriteTargetFile(String name, String logFile, BufferedWriter out) {

		// 获取开始位置
		Long position = map.get(name);
		if(position == null){
			position = 0L;
		}
		
		try (RandomAccessFile raf = new RandomAccessFile(logFile, "r");) {
			// 跳到指定位置
			raf.seek(position);

			out.write("*********<" + name + ">*********" + "\n");
			String line = null;
			while ((line = raf.readLine()) != null) {
				line = new String(line.getBytes("ISO-8859-1"), "utf-8");
				out.write(line);
				out.write("\n");
			
			}
			out.flush();
			// 更新开始位置
			position = raf.getFilePointer();
			map.put(name, position);
			
		} catch (IOException e) {

			e.printStackTrace();
		}
				
		
	}

	/**
	 * 向位置文件中写位置数据
	*/
	private static void writePosition(String path) throws IOException {
		File file = new File(path);
		if (!file.exists()) {
			file.createNewFile();
		}
		try (BufferedWriter out = new BufferedWriter(new FileWriter(file));

		) {
			for(Entry<String, Long> entry : map.entrySet()){
				String key = entry.getKey();
				Long value = entry.getValue();
				String line = key + "=" + value + "\n";
				out.write(line);
			}
			
		
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 读取位置文件的数据内容到map
	*/
	private static void readPosition(String path) {
		File file = new File(path);
		if (!file.exists()) {
			return;
		}
		try (BufferedReader reader = new BufferedReader(new FileReader(path));

		) {
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] splits = line.split("=");
				map.put(splits[0], Long.parseLong(splits[1]));

			}
			System.out.println("map.size==>" + map.size());
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
