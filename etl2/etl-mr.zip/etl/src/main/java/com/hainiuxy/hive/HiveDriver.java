/**
 * HiveDriver.java
 * com.hainiuxy.hive
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.hive;

import org.apache.hadoop.hive.cli.CliDriver;

/**
 * hive 客户端类
 * @author   潘牛                      
 * @Date	 2018年12月4日 	 
 */
public class HiveDriver {
	public static void main(String[] args) throws Exception {
		System.setProperty("jline.WindowsTerminal.directConsole", "false");
		int ret = new CliDriver().run(args);
	    System.exit(ret);
	}

}

