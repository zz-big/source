/**
 * SpiderUtil.java
 * com.hainiuxy.etl.util
 * Copyright (c) 2019, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import com.hainiuxy.etl.job.HainiublHomePageOrc;

/**
 * 字典工具
 * @author   潘牛                      
 * @Date	 2019年3月7日 	 
 */
public class DictUtil {
	
	Map<String, String> urlMap = new HashMap<String, String>();
	
	Map<String, String> spiderMap = new HashMap<String, String>();
	
	/**
	 * 加载字典文件，一个对象只加载一次
	*/
	public void loadFile(){
		InputStream is = HainiublHomePageOrc.class.getResourceAsStream("/data_conf.txt");
		BufferedReader reader = null;
		try{
			reader = new BufferedReader(new InputStreamReader(is,"utf-8"));
			String line = null;
			while((line = reader.readLine()) != null){
				String[] splits = line.split("##");
				if(splits[0].equals("url")){
					String url = splits[1];
					String describe = splits[2];
					urlMap.put(url, describe);
				}else{
					String name = splits[1];
					String describe = splits[2];
					spiderMap.put(name, describe);
				}
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(reader != null){
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if(is != null){
				try {
					is.close();
				} catch (IOException e) {
					
					e.printStackTrace();
					
				}
			}
		}
	}

	public String getReqUrl(String req_url) {
		//找到匹配的url，并获取url和其描述
		for(String url : urlMap.keySet()){
			if(req_url.contains(url)){
				req_url = url;
				break;
			}

		}
		
		return getReqUrlName(req_url);
		
	}
	
	public String getReqUrlName(String req_url){
		return urlMap.get(req_url);
	}
	
	public String getSpiderType(String user_agent) {
		String spider_type = null;
		
		for(String spider : spiderMap.keySet()){
			// 判断useragent是否是已经配置好的爬虫，如果是，直接获取指定爬虫
			if(user_agent.toLowerCase().contains(spider)){
				spider_type = spider;
				break;
			}
		}
		// 如果useragent中没有配置的爬虫，
		//就检查是否带有爬虫的字样，如果带有，就把它归类为未知请求或爬虫，如果不带有，就认为是用户请求
		if(spiderMap.get(spider_type) == null){
			if(user_agent.toLowerCase().contains("spider") || 
					user_agent.toLowerCase().contains("bot") || 
					user_agent.toLowerCase().contains("crawler")){
//				System.out.println(user_agent);
				return "未知请求或爬虫";
			}
//			System.out.println(user_agent);
			return "用户请求";
		}
		
		return spiderMap.get(spider_type);
	}
	
	
	

}

