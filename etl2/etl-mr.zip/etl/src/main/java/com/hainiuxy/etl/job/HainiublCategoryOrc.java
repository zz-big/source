/**
 * HainiublHomePageOrc.java
 * com.hainiuxy.etl
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.mapred.AvroKey;
import org.apache.avro.mapreduce.AvroJob;
import org.apache.avro.mapreduce.AvroKeyInputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hive.ql.io.orc.OrcNewOutputFormat;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.orc.CompressionKind;

import com.hainiuxy.etl.base.BaseMR;
import com.hainiuxy.etl.util.DictUtil;
import com.hainiuxy.etl.util.IPUtil;
import com.hainiuxy.etl.util.OrcUtil;
import com.hainiuxy.etl.util.UserAgentUtil;

import cz.mallat.uasparser.UserAgentInfo;

/**
 * 筛选hainiubl类别的链接请求的数据转化成orc文件
 * @author   潘牛                      
 * @Date	 2018年11月1日 	 
 */
public class HainiublCategoryOrc extends BaseMR{
	
	public static Schema schema = null;
	
	public static Schema.Parser parse = new Schema.Parser();
	
	public static class HainiublHomePageOrcMapper extends Mapper<AvroKey<GenericRecord>, NullWritable, NullWritable, Writable>{
		
		private IPUtil ipUtil = new IPUtil();
		
		UserAgentUtil uaUtil = new UserAgentUtil();
		Text keyOut = new Text();
		
		OrcUtil orcUtil = new OrcUtil();
		
		DictUtil dictUtil = new DictUtil();
		
		@Override
		protected void setup(Context context)
				throws IOException, InterruptedException {
			ipUtil.loadIPFile();
			String orc_schema = "struct<area:string,timeLocal:string,req_url:string,"
					+ "who_req:string,ua_type:string,ua_name:string,spider_type:string,user_agent:string,req_flag:string>";
			orcUtil.setWriteInspector(orc_schema);
			uaUtil.setUASparser();
			dictUtil.loadFile();
		}
		
		@Override
		protected void map(AvroKey<GenericRecord> key, NullWritable value,Context context)
				throws IOException, InterruptedException {
			GenericRecord record = key.datum();
			String remote_ip = String.valueOf(record.get("remote_ip"));
			String time_local = String.valueOf(record.get("time_local"));
			String req_type = String.valueOf(record.get("req_type"));
			String req_url = String.valueOf(record.get("req_url"));
			String who_req = String.valueOf(record.get("who_req"));
			String user_agent = String.valueOf(record.get("user_agent"));
			// 内外部请求标记
			String req_flag = "";
			
			
			if(! checkCategoryReqData(req_type, req_url, who_req)){
//				if(req_url.contains("topics")){
//					System.out.println("===>不匹配url: " + req_url);
//					
//				}
				
				return;
			}
			context.getCounter("hainiu", "topic num2").increment(1L);
		
			//获取ip对应的区域
			String area = ipUtil.getIpArea(remote_ip);
			if(Pattern.matches(".*省.*", area)){
				area = area.substring(0, area.indexOf("省") + 1);
			}else if(Pattern.matches("内蒙古.*", area)){
				area = area.substring(0, 3);
			}else if(Pattern.matches("(^西藏|^广西|^宁夏|^新疆).*", area)){
				area = area.substring(0, 2);
			}else if(Pattern.matches(".*市.*", area)){
				area = area.substring(0, area.indexOf("市") + 1);
			}
			req_url = req_url.replaceAll(" HTTP/.*", "");
			req_url = req_url.contains("?") ? req_url.substring(0, req_url.indexOf("?")) : req_url;
			
//			System.out.println(req_url);
			
//			who_req = who_req.contains("?") ? who_req.substring(who_req.indexOf("/categories"), 
//					who_req.indexOf("?")) : who_req.substring(who_req.indexOf("/categories")) ;
			
			String spiderType = dictUtil.getSpiderType(user_agent);
			//浏览器类型
			String ua_type = "unknown";
			//浏览器名称
			String ua_name = "unknown";
			if("用户请求".equals(spiderType)){
				UserAgentInfo userAgentInfo = uaUtil.parse(user_agent);
				//浏览器类型
				ua_type = userAgentInfo.getType();
				//浏览器名称
				ua_name = userAgentInfo.getUaFamily();
				
				if("unknown".equals(ua_type) && "unknown".equals(ua_name)){
					spiderType = "未知请求或爬虫";
				}
			}
			
			// 判断内部请求，外部请求
			if(who_req.contains("hainiubl") || who_req.contains("hainiuxy")){
				req_flag = "inner_request";
			
			}else{
				if(who_req.equals("-") && spiderType.equals("用户请求")){
					req_flag = "inner_request";
				}else{
//					System.out.println(area + "\001" + req_type + "\001" + req_url + "\001" + who_req  + "\001" + ua_type + "\001" + ua_name + "\001" + spiderType + "\001" + user_agent);
					req_flag = "external_request";
				}
			}
			
			
//			if("未知请求或爬虫".equals(spiderType)){
////				System.out.println(area + "\001" + req_type + "\001" + req_url + "\001" + who_req  + "\001" + spiderType + "\001" + user_agent);
//				if("德国".equals(area)){
//					context.getCounter("hainiu", "德国ip数").increment(1L);
//				}
//			}
			
			
			
			System.out.println(area + "\001" + req_type+ "\001" + req_flag + "\001" + req_url + "\001" + who_req  + "\001" + ua_type + "\001" + ua_name + "\001" + spiderType + "\001" + user_agent);
			//要写入orc文件的数据 
			List<Object> realRow = new ArrayList<Object>();
			realRow.add(area);
			realRow.add(time_local);
			realRow.add(req_url);
			realRow.add(who_req);
			realRow.add(ua_type);
			realRow.add(ua_name);
			realRow.add(spiderType);
			realRow.add(user_agent);
			realRow.add(req_flag);
			
			//将这些数据序列化到orc写Writable
			Writable w = orcUtil.serialize(realRow);
			
			context.write(NullWritable.get(), w);
		}



		/**
		 * 匹配category url请求的topic
		 * @param req_type
		 * @param req_url
		 * @param who_req
		 * @return true:匹配上；false：没匹配上
		*/
		private boolean checkCategoryReqData(String req_type, String req_url, String who_req) {
			if(! "GET".equals(req_type)){
				return false;
			}
			
			// 匹配true；不匹配false
			// 匹配 /topics HTTP/1.1
			//    /topics/ HTTP/1.1
			//    /topics/123 HTTP/1.1
			//    /topics/123? HTTP/1.1
			boolean requrlMatchFlag = Pattern.matches("^/topics(\\s+|/\\s+|/\\d{1,6}(\\?|\\s+|/)).*", req_url);
			
			
//			boolean whoreqMatchFlag = Pattern.matches("^http://hainiubl.com/categories/\\d{1,4}.*", who_req);
			
			if(requrlMatchFlag){
//				System.out.println(req_url);
				return true;
			}
			
			
//			System.out.println(req_url);
			
			return false;
			
		}
		
	}

	@Override
	public Job getJob(Configuration conf) throws Exception {
		
		//设置orc文件snappy压缩
		conf.set("orc.compress", CompressionKind.SNAPPY.name());
		//设置orc文件 有索引
		conf.set("orc.create.index", "true");
		
		Job job = Job.getInstance(conf, getJobNameWithTaskId());
		
		job.setJarByClass(HainiublCategoryOrc.class);
		
		job.setMapperClass(HainiublHomePageOrcMapper.class);
		
		//无reduce
		job.setNumReduceTasks(0);
		
		job.setMapOutputKeyClass(NullWritable.class);
		job.setMapOutputValueClass(Writable.class);
		
		job.setOutputKeyClass(NullWritable.class);
		job.setOutputValueClass(Writable.class);
		
		job.setInputFormatClass(AvroKeyInputFormat.class);
		
		job.setOutputFormatClass(OrcNewOutputFormat.class);
		
		//根据配置的avro.txt 配置文件，获取对应的schema对象
		schema = parse.parse(HainiublCategoryOrc.class.getResourceAsStream("/hainiubl_avro.txt"));
		
		AvroJob.setInputKeySchema(job, schema);
		
		FileInputFormat.addInputPath(job, getFirstJobInputPath());
		
		FileOutputFormat.setOutputPath(job, getJobOutputPath(getJobNameWithTaskId()));
		
		return job;
	}

	@Override
	public String getJobName() {
		
		return "categories_orc";
		
	}

}

