/**
 * Distinct.java
 * com.hainiuxy
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * 对文本单词去重
 * @author   潘牛                      
 * @Date	 2018年9月20日 	 
 */
public class Distinct extends Configured implements Tool{

	public static class DistinctMapper extends Mapper<LongWritable, Text, Text, NullWritable>{
		
		/**
		 * map输出的key： 单词
		 */
		Text keyOut = new Text();
		

		
		//map():每行调用一次
		@Override
		protected void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {

//			System.out.println("------------------------------");
			//one world
			String line = value.toString();
//			System.out.println("map input:" + key.get() + ", " + line);
			//[one, world]
			String[] splits = line.split("\001");
			if(splits.length != 10){
				return;
			}
			String req = splits[3];
			if(req == null){
				return;
			}
//			if(!req.toLowerCase().contains("spider")){
//				return;
//			}
			
			if(!req.contains("GET") && !req.contains("POST")){
				return;
			}
			
			if(req.indexOf("?") > 0){
				req = req.substring(0, req.indexOf("?"));
			}
			String[] tmp = req.split("/");
			if(tmp.length > 3){
				req = tmp[0] + "/" + tmp[1]; 
			}
			keyOut.set(req);
			
			//输出
			context.write(keyOut, NullWritable.get());
			
		}
		
	}
	

	public static class DistinctReducer extends Reducer<Text, NullWritable, Text, NullWritable>{
		
		
	
		
		//reduce()：一个key调用一次
		@Override
		protected void reduce(Text key, Iterable<NullWritable> values, Context context) throws IOException, InterruptedException {
			//统计单词的种类数
			context.getCounter("hainiu", "word type num").increment(1L);
			
//			System.out.println("-------------------------");
			
			StringBuilder sb = new StringBuilder();

			sb.append("reduce input:" + key.toString() + ", [");
			for(NullWritable w : values){
				sb.append("null").append(",");
				
			}
			
			sb.deleteCharAt(sb.length() - 1).append("]");
			System.out.println(key.toString());
			
			context.write(key, NullWritable.get());
			
//			System.out.println("reduce output:" + key.toString() + ",null");
			
		}
		
	}
	

	@Override
	public int run(String[] args) throws Exception {
		//获取Configuration对象
		Configuration conf = getConf();
		//创建job对象
		Job job = Job.getInstance(conf, "Distinct");
		//设置job参数
		
		//设置job运行类
		job.setJarByClass(Distinct.class);
		//设置任务mapper运行类
		job.setMapperClass(DistinctMapper.class);
		//设置任务reducer运行类
		job.setReducerClass(DistinctReducer.class);
		
//		【默认就一个reduce】如果默认，不需要设置，只有reduce个数！=1时设置，
//		设置2个reduce
//		job.setNumReduceTasks(2);
		
		//设置任务mapper输出的key的类型
		job.setMapOutputKeyClass(Text.class);
		//设置任务mapper输出的value的类型
		job.setMapOutputValueClass(NullWritable.class);
		
		//设置最终输出的key类型
		job.setOutputKeyClass(Text.class);
		//设置最终输出的value类型
		job.setOutputValueClass(NullWritable.class);
		
//		【默认是TextInputFormat.class】如果是文本，可以不写；如果是其他的就必须设置此项
		job.setInputFormatClass(TextInputFormat.class);
		
//		【默认是TextOutputFormat.class】如果是文本，可以不写；如果是其他的就必须设置此项		
		job.setOutputFormatClass(TextOutputFormat.class);
		
		
		//设置任务的输入目录
		FileInputFormat.addInputPath(job, new Path(args[0]));
		
		//输出目录Path对象
		Path outputDir = new Path(args[1]);
		//设置任务的输出目录
		FileOutputFormat.setOutputPath(job, outputDir);
		
		//自动删除输出目录
		FileSystem fs = FileSystem.get(conf);
		if(fs.exists(outputDir)){
			//递归删目录
			fs.delete(outputDir, true);
//			System.out.println("output dir【" + outputDir.toString() + "】 is deleted");
		}
		
		//运行job任务， 阻塞的方法
		boolean status = job.waitForCompletion(false);
		
		
		return status ? 0 : 1;
		
	}
	
	public static void main(String[] args) throws Exception {
		//  /tmp/etl/input/distinct /tmp/etl/output/distinct
		System.exit(ToolRunner.run(new Distinct(), args));
	}

}

