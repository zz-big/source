/**
 * Test1.java
 * com.hainiuxy.test
 * Copyright (c) 2019, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.test;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * TODO(这里用一句话描述这个类的作用)
 * <p>
 * TODO(这里描述这个类补充说明 – 可选)
 * @author   潘牛                      
 * @Date	 2019年4月29日 	 
 */
public class Test1 {

	public static void main(String[] args) throws UnsupportedEncodingException {
		String str = "sUKjerJHexwh3xMiUIiB1oqK5Yo44f7CHpWwBxAd&sortOptions%5Bfield%5D=id&sortOptions%5Bdirection%5D=desc&filters%5B0%5D%5Bfield_name%5D=id&filters%5B0%5D%5Btype%5D=key&filters%5B0%5D%5Bvalue%5D=178&filters%5B0%5D%5Bmin_value%5D=&filters%5B0%5D%5Bmax_value%5D=&filters%5B1%5D%5Bfield_name%5D=seotitle&filters%5B1%5D%5Btype%5D=text&filters%5B1%5D%5Bvalue%5D=&filters%5B1%5D%5Bmin_value%5D=&filters%5B1%5D%5Bmax_value%5D=&filters%5B2%5D%5Bfield_name%5D=seokeywords&filters%5B2%5D%5Btype%5D=text&filters%5B2%5D%5Bvalue%5D=&filters%5B2%5D%5Bmin_value%5D=&filters%5B2%5D%5Bmax_value%5D=&filters%5B3%5D%5Bfield_name%5D=seodescription&filters%5B3%5D%5Btype%5D=text&filters%5B3%5D%5Bvalue%5D=&filters%5B3%5D%5Bmin_value%5D=&filters%5B3%5D%5Bmax_value%5D=&filters%5B4%5D%5Bfield_name%5D=user&filters%5B4%5D%5Btype%5D=belongs_to&filters%5B4%5D%5Bvalue%5D=&filters%5B4%5D%5Bmin_value%5D=&filters%5B4%5D%5Bmax_value%5D=&filters%5B5%5D%5Bfield_name%5D=category&filters%5B5%5D%5Btype%5D=belongs_to&filters%5B5%5D%5Bvalue%5D=&filters%5B5%5D%5Bmin_value%5D=&filters%5B5%5D%5Bmax_value%5D=&filters%5B6%5D%5Bfield_name%5D=body_original&filters%5B6%5D%5Btype%5D=text&filters%5B6%5D%5Bvalue%5D=&filters%5B6%5D%5Bmin_value%5D=&filters%5B6%5D%5Bmax_value%5D=&filters%5B7%5D%5Bfield_name%5D=order&filters%5B7%5D%5Btype%5D=text&filters%5B7%5D%5Bvalue%5D=&filters%5B7%5D%5Bmin_value%5D=&filters%5B7%5D%5Bmax_value%5D=&filters%5B8%5D%5Bfield_name%5D=is_excellent&filters%5B8%5D%5Btype%5D=enum&filters%5B8%5D%5Bvalue%5D=&filters%5B8%5D%5Bmin_value%5D=&filters%5B8%5D%5Bmax_value%5D=&filters%5B9%5D%5Bfield_name%5D=is_blocked&filters%5B9%5D%5Btype%5D=enum&filters%5B9%5D%5Bvalue%5D=&filters%5B9%5D%5Bmin_value%5D=&filters%5B9%5D%5Bmax_value%5D=&filters%5B10%5D%5Bfield_name%5D=view_count&filters%5B10%5D%5Btype%5D=number&filters%5B10%5D%5Bvalue%5D=&filters%5B10%5D%5Bmin_value%5D=&filters%5B10%5D%5Bmax_value%5D=&page=1&filter_by=&filter_by_id=0";
		System.out.println(str);
		String str1 = URLDecoder.decode(str, "utf-8");
		System.out.println(str1);
	}

}
