/**
 * WordMaxJob.java
 * com.hainiuxy.mrrun
 * Copyright (c) 2018, 海牛版权所有.
 * @author   潘牛                      
*/

package com.hainiuxy.etl.job;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.mapreduce.CounterGroup;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

import com.hainiuxy.etl.util.JobRunResult;
import com.hainiuxy.etl.util.JobRunUtil;
import com.hainiuxy.etl.util.DBUtil;

/**
 *  txt 文件转avro文件的任务链
 * @author   潘牛                      
 * @Date	 2018年9月29日 	 
 */
public class HainiublEtlToAvroJob extends Configured implements Tool{

	@Override
	public int run(String[] args) throws Exception {
		//通过getConf(),获取configuration，这样可以把-D参数传过来
		Configuration conf = getConf();
		
		//创建任务链JobControl对象
		JobControl jobc = new JobControl("HainiublEtlToAvro");
		
		HainiublEtlToAvro avro = new HainiublEtlToAvro();
		avro.setConf(conf);
		
		ControlledJob toAvroJob = avro.getControlledJob();
	
		jobc.addJob(toAvroJob);
		
		
		
		JobRunResult result = JobRunUtil.run(jobc);
		result.print(false);
		
		CounterGroup group = result.getCounters(avro.getJobNameWithTaskId()).getGroup("hainiubl_log");
		saveJobCounter(group);
		
		return 0; 
		
	}


	private void saveJobCounter(CounterGroup group) {
		String time_local = new SimpleDateFormat("yyyyMMdd").format(new Date());
		long total_num = group.findCounter("total num").getValue();
		long invalid_num = group.findCounter("invalid num").getValue();
		long valid_num = group.findCounter("valid num").getValue();
		long ip_num = group.findCounter("ip num").getValue();
		Connection conn = null;
		try {
			
			String selectSql = "delete from hainiubl_valid_count where time_local = ?";
		
			conn = DBUtil.getConnection();
			PreparedStatement pstmt1 = conn.prepareStatement(selectSql);
			pstmt1.setString(1, time_local);
			pstmt1.executeUpdate();
			
			
			String sql = "insert into hainiubl_valid_count(time_local,total_num,invalid_num,valid_num,ip_num ) values(?,?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, time_local);
			pstmt.setLong(2, total_num);
			pstmt.setLong(3, invalid_num);
			pstmt.setLong(4, valid_num);
			pstmt.setLong(5, ip_num);
			pstmt.executeUpdate();
		} catch (Exception e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}finally{
			DBUtil.release(conn);
		}
		
	}



	public static void main(String[] args) throws Exception {
//		-Dtask.id=1031 -Dtask.input.dir=/tmp/etl/avro/input -Dtask.base.dir=/tmp/etl/avro
		System.exit(ToolRunner.run(new HainiublEtlToAvroJob(), args));
	}

}

